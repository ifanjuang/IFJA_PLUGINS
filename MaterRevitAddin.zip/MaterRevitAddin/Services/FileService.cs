﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Mater2026.Services
{
    public static class FileService
    {
        public static readonly string[] ImgExt = { ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp" };

        public static bool HasKeyImage(string folder)
        {
            var name = Path.GetFileName(folder);
            foreach (var ext in ImgExt)
                if (File.Exists(Path.Combine(folder, name + ext))) return true;
            return false;
        }

        public static IEnumerable<string> EnumerateOriginals(string folder)
        {
            if (!Directory.Exists(folder)) yield break;
            foreach (var f in Directory.EnumerateFiles(folder))
            {
                var ext = Path.GetExtension(f).ToLowerInvariant();
                var name = Path.GetFileNameWithoutExtension(f).ToLowerInvariant();
                if (!ImgExt.Contains(ext, StringComparer.OrdinalIgnoreCase)) continue;
                // exclude sized thumbs
                if (name.EndsWith("_256") || name.EndsWith("_512") || name.EndsWith("_1024")) continue;
                if (name.Contains("thumb")) continue;
                yield return f;
            }
        }

        public static string? ResolveThumbSource(string folder)
        {
            var name = Path.GetFileName(folder);
            foreach (var ext in ImgExt)
            {
                var exact = Path.Combine(folder, name + ext);
                if (File.Exists(exact)) return exact;
            }
            // fallback to any already-sized thumb (prefer smallest first)
            foreach (var s in new[] { "_256", "_512", "_1024" })
            {
                var p = Path.Combine(folder, name + s + ".jpg");
                if (File.Exists(p)) return p;
            }
            return null;
        }

        public static bool HasSizedThumb(string folder, int size)
        {
            var name = Path.GetFileName(folder);
            var p = Path.Combine(folder, $"{name}_{size}.jpg");
            return File.Exists(p);
        }
    }
}
