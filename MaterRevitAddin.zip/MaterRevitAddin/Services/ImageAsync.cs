﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Mater2026.Services
{
    /// <summary>
    /// Non-blocking image loader with cancellation.
    /// Usage in XAML:  s:ImageAsync.AsyncSourcePath="{Binding ThumbPath}"
    /// </summary>
    public static class ImageAsync
    {
        public static readonly DependencyProperty AsyncSourcePathProperty =
            DependencyProperty.RegisterAttached(
                "AsyncSourcePath",
                typeof(string),
                typeof(ImageAsync),
                new PropertyMetadata(null, OnAsyncSourceChanged));

        public static string? GetAsyncSourcePath(DependencyObject obj) =>
            (string?)obj.GetValue(AsyncSourcePathProperty);

        public static void SetAsyncSourcePath(DependencyObject obj, string? value) =>
            obj.SetValue(AsyncSourcePathProperty, value);

        // Per-image cancellation token
        private static readonly DependencyProperty CtsProperty =
            DependencyProperty.RegisterAttached("Cts", typeof(CancellationTokenSource), typeof(ImageAsync));

        private static CancellationTokenSource? GetCts(DependencyObject obj) =>
            (CancellationTokenSource?)obj.GetValue(CtsProperty);

        private static void SetCts(DependencyObject obj, CancellationTokenSource? value) =>
            obj.SetValue(CtsProperty, value);

        private static async void OnAsyncSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is not System.Windows.Controls.Image img) return;

            // cancel any previous decode
            GetCts(img)?.Cancel();
            var cts = new CancellationTokenSource();
            SetCts(img, cts);
            var token = cts.Token;

            var path = e.NewValue as string;
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                img.Source = null;
                return;
            }

            try
            {
                var bmp = await Task.Run(() =>
                {
                    token.ThrowIfCancellationRequested();
                    var bi = new BitmapImage();
                    bi.BeginInit();
                    bi.CacheOption = BitmapCacheOption.OnLoad;
                    bi.UriSource = new Uri(path, UriKind.Absolute);
                    bi.EndInit();
                    bi.Freeze();
                    return bi;
                }, token);

                if (!token.IsCancellationRequested)
                    img.Source = bmp;
            }
            catch (OperationCanceledException) { /* ignore */ }
            catch
            {
                ToastService.Show($"Échec de la vignette: {System.IO.Path.GetFileName(path)}");
            }
        }
    }
}
