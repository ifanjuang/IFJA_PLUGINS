﻿using System;
using System.IO;
using System.Windows.Media.Imaging;

namespace Mater2026.Services
{
    public static class ThumbnailService
    {
        // Generate thumbnail; overwrite=false => only missing/outdated
        public static string GenerateThumb(string folder, int size, bool overwrite)
        {
            var name = Path.GetFileName(folder);
            var target = Path.Combine(folder, $"{name}_{size}.jpg");

            var src = FileService.ResolveThumbSource(folder);
            if (src == null) return target;

            bool outdated = File.Exists(target) &&
                            File.GetLastWriteTimeUtc(target) < File.GetLastWriteTimeUtc(src);
            bool needGen = overwrite || !File.Exists(target) || outdated;
            if (!needGen) return target;

            try
            {
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.UriSource = new Uri(src, UriKind.Absolute);
                if (size > 0) bmp.DecodePixelWidth = size;
                bmp.EndInit();
                bmp.Freeze();

                var enc = new JpegBitmapEncoder { QualityLevel = 88 };
                enc.Frames.Add(BitmapFrame.Create(bmp));
                using var fs = new FileStream(target, FileMode.Create, FileAccess.Write, FileShare.None);
                enc.Save(fs);
            }
            catch
            {
                // swallow; UI will show toast via ImageAsync on load failure
            }
            return target;
        }
    }
}
