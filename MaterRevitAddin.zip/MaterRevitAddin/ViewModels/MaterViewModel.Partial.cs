﻿using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Mater2026.Models;
using Mater2026.Services;

namespace Mater2026.ViewModels
{
    public partial class MaterViewModel
    {
        private readonly UIApplication _uiapp;

        public MaterViewModel(UIApplication uiapp)
        {
            _uiapp = uiapp;

            // initial materials list
            foreach (var m in RevitMaterialService.GetProjectMaterials(_uiapp.ActiveUIDocument))
                ProjectMaterials.Add(m);
        }

        // Collections bound to UI
        public ObservableCollection<(ElementId Id, string Name)> ProjectMaterials { get; } = new();
        public ObservableCollection<FolderItem> GridFolders { get; } = new();
        public ObservableCollection<MapSlot> MapTypes { get; } = new();

        // Parameters bucket (you already have UiParameters class)
        public UiParameters Params { get; } = new();

        // Selection + state
        public (ElementId Id, string Name)? SelectedMaterial { get; set; }
        public string? CurrentGridRoot { get; private set; }
        public int ThumbSize { get; set; } = 256;   // current grid thumb size

        // Called by the window when Tree selection changes
        public void SelectTreeNode(string folderPath)
        {
            CurrentGridRoot = folderPath;
            GridFolders.Clear();

            if (!Directory.Exists(folderPath)) return;

            foreach (var sub in Directory.EnumerateDirectories(folderPath))
            {
                var name = Path.GetFileName(sub);
                var fi = new FolderItem
                {
                    Name = name,
                    FullPath = sub,
                    ThumbSize = ThumbSize
                };
                fi.RefreshThumbPath(); // choose _256/_512/_1024 or fallback
                GridFolders.Add(fi);
            }
        }

        // Leaf only: detect maps + set slots
        public async Task DetectMapsForFolderAsync(string folderPath)
        {
            await Task.Yield();
            MapTypes.Clear();
            foreach (var s in DetectionService.DetectSlots(folderPath))
                MapTypes.Add(s);

            // Standard params after detection
            Params.FolderPath = folderPath;
            Params.MaterialName = Path.GetFileName(folderPath); // appearance name
            Params.WidthCm = 300;
            Params.HeightCm = 300;
            Params.RotationDeg = 0;
            Params.TilesX = 1;
            Params.TilesY = 1;
            Params.Tint = (255, 255, 255);
        }

        // Generate missing thumbs in direct children for the requested sizes
        public async Task GenerateMissingThumbsForDirectChildrenAsync(string root, int[] sizes)
        {
            await Task.Run(() =>
            {
                foreach (var sub in Directory.EnumerateDirectories(root))
                {
                    foreach (var s in sizes)
                    {
                        var name = Path.GetFileName(sub);
                        var target = Path.Combine(sub, $"{name}_{s}.jpg");
                        if (!File.Exists(target))
                            ThumbnailService.GenerateThumb(sub, s, overwrite: false);
                    }
                }
            });

            // refresh grid entries
            SelectTreeNode(root);
        }

        // Create appearance & material according to Params and current MapTypes
        public async Task CreateMaterialAndAppearanceFromParams()
        {
            await Task.Yield();

            var uidoc = _uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var appearanceName = string.IsNullOrWhiteSpace(Params.MaterialName) ? "Apparence" : Params.MaterialName;
            var app = RevitMaterialService.GetOrCreateAppearanceByFolder(doc, appearanceName);
            RevitMaterialService.WriteAppearanceFolderPath(app, Params.FolderPath ?? "");

            var maps = MapTypes
                .Where(ms => ms.Assigned != null)
                .ToDictionary(ms => ms.Type, ms => (path: ms.Assigned!.FullPath, invert: ms.Invert));

            RevitMaterialService.ApplyUiToAppearance(app, maps, Params.WidthCm, Params.HeightCm, Params.RotationDeg, Params.Tint);

            if (SelectedMaterial == null)
            {
                // Create a new material with the same name as the appearance
                var mat = RevitMaterialService.CreateMaterial(doc, app.Name, app);
                SelectedMaterial = (mat.Id, mat.Name);
                // Keep list in sync
                if (!ProjectMaterials.Any(x => x.Id == mat.Id))
                    ProjectMaterials.Add((mat.Id, mat.Name));
            }
            else
            {
                // Switch selected material to this appearance
                var mat = (Material)doc.GetElement(SelectedMaterial.Value.Id);
                RevitMaterialService.ReplaceMaterialAppearance(mat, app);
            }
        }

        public async Task ReplaceSelectedMaterialAppearanceFromParams()
        {
            await Task.Yield();
            if (SelectedMaterial == null) return;

            var uidoc = _uiapp.ActiveUIDocument;
            var doc = uidoc.Document;

            var appearanceName = string.IsNullOrWhiteSpace(Params.MaterialName) ? "Apparence" : Params.MaterialName;
            var app = RevitMaterialService.GetOrCreateAppearanceByFolder(doc, appearanceName);
            RevitMaterialService.WriteAppearanceFolderPath(app, Params.FolderPath ?? "");

            var maps = MapTypes
                .Where(ms => ms.Assigned != null)
                .ToDictionary(ms => ms.Type, ms => (path: ms.Assigned!.FullPath, invert: ms.Invert));

            RevitMaterialService.ApplyUiToAppearance(app, maps, Params.WidthCm, Params.HeightCm, Params.RotationDeg, Params.Tint);

            var mat = (Material)doc.GetElement(SelectedMaterial.Value.Id);
            RevitMaterialService.ReplaceMaterialAppearance(mat, app);
        }
    }
}
