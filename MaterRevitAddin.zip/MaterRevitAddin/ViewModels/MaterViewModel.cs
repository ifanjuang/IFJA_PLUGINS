using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Mater2026.Models;
using Mater2026.Services;

namespace Mater2026.ViewModels
{
    // ... FolderItem and UiParameters stay the same ...

    public class MaterViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<FolderItem> GridFolders { get; } = new();
        public ObservableCollection<(ElementId Id, string Name)> ProjectMaterials { get; } = new();
        public ObservableCollection<MapSlot> MapTypes { get; } = new();
        public UiParameters Params { get; } = new();

        private readonly UIApplication _uiapp;
        private readonly UIDocument _uidoc;
        private CancellationTokenSource? _thumbCts;

        public RelayCommand<string> SelectTreeNodeCommand { get; }
        public RelayCommand<FolderItem> GridTileLeftClickCommand { get; }
        public RelayCommand ToggleGalleryCommand { get; }
        public RelayCommand SetThumb512Command { get; }
        public RelayCommand SetThumb1024Command { get; }
        public RelayCommand SetThumb2048Command { get; }
        public RelayCommand GenerateMissingThumbsCommand { get; }
        public RelayCommand RegenerateAllThumbsCommand { get; }
        public RelayCommand CreateCommand { get; }
        public RelayCommand ReplaceCommand { get; }
        public RelayCommand AssignCommand { get; }
        public RelayCommand PipetteCommand { get; }

        private bool _isGallery;
        public bool IsGallery { get => _isGallery; set { _isGallery = value; OnPropertyChanged(); } }

        private int _thumbSize = 512;
        public int ThumbSize { get => _thumbSize; set { _thumbSize = value; foreach (var f in GridFolders) f.ThumbSize = value; OnPropertyChanged(); } }

        private (ElementId Id, string Name)? _selectedMaterial;
        public (ElementId Id, string Name)? SelectedMaterial
        {
            get => _selectedMaterial;
            set { _selectedMaterial = value; OnPropertyChanged(); OnSelectedMaterialChanged(); }
        }

        private bool _isThumbWorking;
        public bool IsThumbWorking { get => _isThumbWorking; set { _isThumbWorking = value; OnPropertyChanged(); } }
        private int _thumbDone;
        public int ThumbDone { get => _thumbDone; set { _thumbDone = value; OnPropertyChanged(); } }
        private int _thumbTotal;
        public int ThumbTotal { get => _thumbTotal; set { _thumbTotal = value; OnPropertyChanged(); } }

        public event PropertyChangedEventHandler? PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string? n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

        public MaterViewModel(UIApplication uiapp)
        {
            _uiapp = uiapp;
            _uidoc = uiapp.ActiveUIDocument;
            RefreshMaterials();

            SelectTreeNodeCommand = new RelayCommand<string>(SelectTreeNode);
            GridTileLeftClickCommand = new RelayCommand<FolderItem>(OnGridTileLeftClick);
            ToggleGalleryCommand = new RelayCommand(() => IsGallery = !IsGallery);

            SetThumb512Command = new RelayCommand(() => { ThumbSize = 512; _ = EnsureThumbsAsync(ThumbSize, overwrite: false, System.Threading.CancellationToken.None); });
            SetThumb1024Command = new RelayCommand(() => { ThumbSize = 1024; _ = EnsureThumbsAsync(ThumbSize, overwrite: false, System.Threading.CancellationToken.None); });
            SetThumb2048Command = new RelayCommand(() => { ThumbSize = 2048; _ = EnsureThumbsAsync(ThumbSize, overwrite: false, System.Threading.CancellationToken.None); });

            GenerateMissingThumbsCommand = new RelayCommand(() => _ = EnsureThumbsAsync(ThumbSize, overwrite: false, System.Threading.CancellationToken.None));
            RegenerateAllThumbsCommand = new RelayCommand(() => _ = EnsureThumbsAsync(ThumbSize, overwrite: true, System.Threading.CancellationToken.None));


            CreateCommand = new RelayCommand(Create, CanCreate);
            ReplaceCommand = new RelayCommand(Replace, CanReplace);
            AssignCommand = new RelayCommand(StartAssignMode, () => SelectedMaterial != null || ProjectMaterials.Count > 0);
            PipetteCommand = new RelayCommand(StartPipetteOnce);

            Params.OnMaterialNameChanged += OnMaterialNameEdited;
        }

        void RefreshMaterials()
        {
            ProjectMaterials.Clear();
            foreach (var m in RevitMaterialService.GetProjectMaterials(_uidoc))
                ProjectMaterials.Add(m);
        }

        public async void SelectTreeNode(string folderPath)
        {
            if (string.IsNullOrWhiteSpace(folderPath)) return;
            Params.FolderPath = folderPath;
            if (!Directory.Exists(folderPath)) return;
            GridFolders.Clear();

            _thumbCts?.Cancel();
            _thumbCts = new CancellationTokenSource();
            foreach (var sub in Directory.EnumerateDirectories(folderPath))
            {
                if (Directory.EnumerateDirectories(sub).Any())
                    GridFolders.Add(new FolderItem { FullPath = sub, ThumbSize = ThumbSize });
            }
            await EnsureThumbsAsync(ThumbSize, overwrite: false, _thumbCts.Token);
        }

        public void OnGridTileLeftClick(FolderItem? item)
        {
            if (item == null) return;
            if (!Services.FileService.HasKeyImage(item.FullPath))
            {
                System.Windows.MessageBox.Show(
                    "Image-clé manquante : la détection s'exécute uniquement si le dossier contient une image nommée comme le dossier.",
                    "Détection PBR", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                return;
            }
            MapTypes.Clear();
            foreach (var s in DetectionService.DetectSlots(item.FullPath)) MapTypes.Add(s);
            Params.FolderPath = item.FullPath;
        }

        async Task EnsureThumbsAsync(int size, bool overwrite, CancellationToken token = default)
        {
            IsThumbWorking = true;
            ThumbDone = 0;
            ThumbTotal = GridFolders.Count;

            async Task GenerateOne(FolderItem f)
            {
                if (token.IsCancellationRequested) return;
                await Task.Run(() =>
                {
                    var th = new System.Threading.Thread(() =>
                    {
                        try { ThumbnailService.GenerateThumb(f.FullPath, size, overwrite); } catch { }
                    });
                    th.IsBackground = true;
                    th.SetApartmentState(System.Threading.ApartmentState.STA);
                    th.Start();
                    th.Join();
                }, token);

                if (!token.IsCancellationRequested)
                {
                    await System.Windows.Application.Current.Dispatcher.InvokeAsync(() =>
                    {
                        f.TouchThumb();
                        ThumbDone++;
                    }, DispatcherPriority.Background);
                }
            }

            foreach (var f in GridFolders)
            {
                if (token.IsCancellationRequested) break;
                await GenerateOne(f);
            }

            IsThumbWorking = false;
        }

        bool Ready()
        {
            var hasAlbedo = MapTypes.Any(s => s.Type == MapType.Albedo && s.Assigned != null);
            return hasAlbedo && Params.WidthCm > 0 && Params.HeightCm > 0 && Params.TilesX >= 1 && Params.TilesY >= 1;
        }
        bool CanCreate() => SelectedMaterial == null && Ready();
        bool CanReplace() => SelectedMaterial != null && Ready();

        void Create()
        {
            var folder = Params.FolderPath;
            if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
            {
                System.Windows.MessageBox.Show("Dossier invalide.", "Créer", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
                return;
            }
            var folderName = Path.GetFileName(folder);
            var doc = _uidoc.Document;

            var app = RevitMaterialService.GetOrCreateAppearanceByFolder(doc, folderName);
            RevitMaterialService.WriteAppearanceFolderPath(app, folder);

            var maps = MapTypes.ToDictionary(s => s.Type, s => (path: s.Assigned?.FullPath, invert: s.Invert));
            RevitMaterialService.ApplyUiToAppearance(app, maps, Params.WidthCm, Params.HeightCm, Params.RotationDeg, Params.Tint);

            var matName = string.IsNullOrWhiteSpace(Params.MaterialName) ? folderName : Params.MaterialName;
            var mat = RevitMaterialService.CreateMaterial(doc, matName, app);

            RefreshMaterials();
            SelectedMaterial = ProjectMaterials.FirstOrDefault(m => m.Id == mat.Id);
            System.Windows.MessageBox.Show("Matériau créé et sélectionné.", "Créer", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            CreateCommand.RaiseCanExecuteChanged();
            ReplaceCommand.RaiseCanExecuteChanged();
        }

        void Replace()
        {
            if (SelectedMaterial == null) return;
            var folder = Params.FolderPath;
            var folderName = Path.GetFileName(folder);
            var doc = _uidoc.Document;

            var (mat, _) = RevitMaterialService.GetMaterialAndAppearance(doc, SelectedMaterial.Value.Id);
            if (mat == null) return;

            var app = RevitMaterialService.GetOrCreateAppearanceByFolder(doc, folderName);
            RevitMaterialService.WriteAppearanceFolderPath(app, folder);

            var maps = MapTypes.ToDictionary(s => s.Type, s => (path: s.Assigned?.FullPath, invert: s.Invert));
            RevitMaterialService.ApplyUiToAppearance(app, maps, Params.WidthCm, Params.HeightCm, Params.RotationDeg, Params.Tint);

            RevitMaterialService.ReplaceMaterialAppearance(mat, app);
            System.Windows.MessageBox.Show("Matériau mis à jour.", "Remplacer", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
        }

        void OnMaterialNameEdited(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return;
            var match = ProjectMaterials.FirstOrDefault(m => m.Name.Equals(text.Trim(), StringComparison.CurrentCultureIgnoreCase));
            if (match.Id != ElementId.InvalidElementId) SelectedMaterial = match;
        }

        void OnSelectedMaterialChanged()
        {
            AssignCommand.RaiseCanExecuteChanged();
            CreateCommand.RaiseCanExecuteChanged();
            ReplaceCommand.RaiseCanExecuteChanged();

            if (SelectedMaterial == null) return;

            var res = System.Windows.MessageBox.Show(
                $"Récupérer les paramètres depuis \"{SelectedMaterial.Value.Name}\" ?",
                "Paramètres matériau",
                System.Windows.MessageBoxButton.YesNo,
                System.Windows.MessageBoxImage.Question,
                System.Windows.MessageBoxResult.Yes);

            if (res == System.Windows.MessageBoxResult.Yes)
            {
                var rb = RevitMaterialService.ReadUiFromAppearanceAndMaterial(_uidoc.Document, SelectedMaterial.Value.Id);
                if (!string.IsNullOrWhiteSpace(rb.FolderPath)) Params.FolderPath = rb.FolderPath;
                if (rb.WidthCm > 0) Params.WidthCm = rb.WidthCm;
                if (rb.HeightCm > 0) Params.HeightCm = rb.HeightCm;
                Params.RotationDeg = rb.RotationDeg;
                Params.TilesX = rb.TilesX;
                Params.TilesY = rb.TilesY;
                Params.Tint = rb.Tint;

                MapTypes.Clear();
                foreach (var t in new[] { MapType.Albedo, MapType.Roughness, MapType.Reflection, MapType.Bump, MapType.Refraction, MapType.Illumination })
                {
                    var slot = new MapSlot(t);
                    if (rb.Maps.TryGetValue(t, out var mp) && mp.path != null)
                    {
                        slot.Assigned = new Mater2026.Models.MapFile(mp.path, t);
                        slot.Invert = mp.invert;
                    }
                    if (t == MapType.Albedo && rb.Tint.HasValue) slot.Tint = rb.Tint;
                    MapTypes.Add(slot);
                }
            }
        }

        void StartAssignMode()
        {
            var startMat = SelectedMaterial?.Id ?? ProjectMaterials.FirstOrDefault().Id;
            if (startMat == ElementId.InvalidElementId)
            {
                System.Windows.MessageBox.Show("Aucun matériau disponible...", "ASSIGNER",
                    System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                return;
            }

            var handler = new PaintModeHandler
            {
                UiDoc = _uidoc,
                CurrentMaterialId = startMat,
                OnMaterialSampled = (matId) =>
                {
                    var match = ProjectMaterials.FirstOrDefault(m => m.Id == matId);
                    if (match.Id != ElementId.InvalidElementId) SelectedMaterial = match;
                }
            };

            var ev = ExternalEvent.Create(handler);
            handler.OnBegin = () => System.Windows.Application.Current?.Dispatcher.Invoke(() => AppHide?.Invoke());
            handler.OnEnd = (commit) => System.Windows.Application.Current?.Dispatcher.Invoke(() => AppShow?.Invoke());
            ev.Raise();
        }

        void StartPipetteOnce()
        {
            var handler = new PipetteHandler
            {
                UiDoc = _uidoc,
                OnPicked = (matId) =>
                {
                    var match = ProjectMaterials.FirstOrDefault(m => m.Id == matId);
                    if (match.Id != ElementId.InvalidElementId) SelectedMaterial = match;
                    else System.Windows.MessageBox.Show("Le matériau prélevé n'existe pas dans ce projet.", "Pipette",
                        System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                }
            };
            var ev = ExternalEvent.Create(handler);
            handler.OnBegin = () => System.Windows.Application.Current?.Dispatcher.Invoke(() => AppHide?.Invoke());
            handler.OnEnd = (ok) => System.Windows.Application.Current?.Dispatcher.Invoke(() => AppShow?.Invoke());
            ev.Raise();
        }

        public Action? AppHide { get; set; }
        public Action? AppShow { get; set; }
    }
}
