﻿namespace Mater2026.Models
{
    public enum MapType
    {
        Albedo,
        Roughness,
        Reflection,
        Bump,
        Refraction,
        Illumination,
        Unknown
    }
}