﻿namespace Mater2026.Models
{
    public enum MapType
    {
        Albedo,
        Roughness,
        Bump,
        Refraction,
        Reflection,
        Metalness,
        Illumination,
        Unknown,

    }
}