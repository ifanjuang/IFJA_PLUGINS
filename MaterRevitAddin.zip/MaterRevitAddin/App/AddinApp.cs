﻿using System;
using System.Reflection;
using System.Windows.Media.Imaging;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;

namespace Mater2026.App
{
    public class AddinApp : IExternalApplication
    {
        public static UIControlledApplication? UiApp { get; private set; }
        public static UI.MaterWindow? Window { get; internal set; }

        public Result OnStartup(UIControlledApplication application)
        {
            UiApp = application;

            var panel = application.CreateRibbonPanel("Mater 2026");
            var btnData = new PushButtonData(
                "MaterOpen", "Mater 2026",
                Assembly.GetExecutingAssembly().Location,
                "Mater2026.App.OpenWindowCommand");

            if (panel.AddItem(btnData) is PushButton btn)
            {
                btn.ToolTip = "Ouvrir Mater (fenêtre modeless)";

                // Optional: icons from ProgramData (or embed as resources)
                try
                {
                    var icon32 = @"C:\ProgramData\Autodesk\Revit\Addins\2026\Mater2026\icon32.png";
                    var icon16 = @"C:\ProgramData\Autodesk\Revit\Addins\2026\Mater2026\icon16.png";
                    if (System.IO.File.Exists(icon32))
                        btn.LargeImage = new BitmapImage(new Uri(icon32));
                    if (System.IO.File.Exists(icon16))
                        btn.Image = new BitmapImage(new Uri(icon16));
                }
                catch { }
            }

            return Result.Succeeded;
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            if (Window != null) { try { Window.Close(); } catch { } Window = null; }
            return Result.Succeeded;
        }
    }

    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class OpenWindowCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
        {
            var uiapp = commandData.Application;

            if (AddinApp.Window is { IsLoaded: true })
            {
                if (!AddinApp.Window.IsVisible) AddinApp.Window.Show();
                AddinApp.Window.Activate();
            }
            else
            {
                AddinApp.Window = new UI.MaterWindow(uiapp);
                AddinApp.Window.Show();
                AddinApp.Window.Activate();
            }
            return Result.Succeeded;
        }
    }
}
